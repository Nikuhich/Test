const slider_block = document.querySelector('.slider__window')
const slider_btn_right = document.querySelector('.slider__controls-btn-right')
const slider_btn_left = document.querySelector('.slider__controls-btn-left')
const slider_images = document.querySelectorAll('.slider__block')
const slider_points = document.querySelectorAll('.slider__points-box')

slider_btn_right.style = 'display: none'

let counter = 1

slider_btn_left.addEventListener('click', function () {
    counter++
    for (let img = 0; img < slider_images.length; img++) {

    }

    for (let point = 0; point < slider_points.length; point++) {
        slider_points[point].classList.remove('slider__points-box-active')

        slider_points[counter - 1].classList.add('slider__points-box-active')
    }

    slider_btn_right.style = 'display: block'

    if (counter > slider_images.length - 1) {
        slider_block.style = `transform: translateX(${-800 * counter + 800}px)`
        slider_btn_left.style = 'display: none'
    } else {
        slider_block.style = `transform: translateX(${-800 * counter + 800}px)`
    }
})

slider_btn_right.addEventListener('click', function () {
    counter--
    for (let img = 0; img < slider_images.length; img++) {

    }

    for (let point = 0; point < slider_points.length; point++) {
        slider_points[point].classList.remove('slider__points-box-active')

        slider_points[counter - 1].classList.add('slider__points-box-active')
    }

    slider_btn_left.style = 'display: block'

    if (counter == 1) {
        slider_block.style = `transform: translateX(0)`
        slider_btn_right.style = 'display: none'
    } else if (counter == 2) {
        slider_block.style = `transform: translateX(${800 * counter - 2400}px)`
    } else if (counter > 2) {
        slider_block.style = `transform: translateX(${800 * counter - counter * 1600 + 800}px)`
    }
})

for (let point = 0; point < slider_points.length; point++) {
    slider_points[point].addEventListener('click', function () {
        console.log(point);
        counter = point + 1
        
        if(counter == 1){
            slider_btn_right.style = 'display: none'
        }
        
        if(counter > 1){
            slider_btn_right.style = 'display: block'
        }
        
        if (counter == slider_images.length) {
            slider_btn_left.style = 'display: none'
        }
        
        if(counter < slider_images.length){
            slider_btn_left.style = 'display: block'
        }
        
        for (let point = 0; point < slider_points.length; point++) {
            slider_points[point].classList.remove('slider__points-box-active')
        }
        
        slider_points[point].classList.add('slider__points-box-active')

        slider_block.style = `transform: translateX(${-800 * (point + 1) + 800}px)`
    })
}